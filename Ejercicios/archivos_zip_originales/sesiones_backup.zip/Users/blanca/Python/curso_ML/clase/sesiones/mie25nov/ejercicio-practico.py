"""
Caso Práctico: Manejo de Excepciones en División de Números

Requerimientos de Ejecución:
1. Solicitar dos números al usuario.
2. Implementar un bloque try-except.
3. Capturar la excepción ValueError (por si introducen caracteres no numéricos).
4. Capturar la excepción ZeroDivisionError (por si dividen entre cero).
5. Mostrar el resultado o un mensaje de error amigable y descriptivo.

Evidencias obligatorias a entregar:
- Archivo .py
- Captura de pantalla provocando un error de división por cero manejado.

Autor: Blanca de Uña Martín
Curso: Python Fundae - Evaluación Módulo 4
"""


def division_segura():
    print("=" * 45)
    print("     PROGRAMA DE DIVISIÓN SEGURA DE NÚMEROS")
    print("=" * 45)

    try:
        # 1. Solicitar dos números al usuario
        # Se utiliza float para admitir tanto enteros como decimales
        num1 = float(input("Introduce el primer número (dividendo): "))
        num2 = float(input("Introduce el segundo número (divisor): "))

        # Operación de división
        resultado = num1 / num2

    # 3. Capturar excepción si introducen caracteres no numéricos
    except ValueError:
        print("\n❌ Error (ValueError): Debes introducir valores numéricos válidos.")

    # 4. Capturar excepción si intentan dividir entre cero
    except ZeroDivisionError:
        print("\n❌ Error (ZeroDivisionError): No es posible dividir entre cero.")
        print("   Por favor, introduce un divisor diferente de 0.")

    # 5. Mostrar el resultado si la operación se realizó con éxito
    else:
        # Formatear a entero si no tiene parte decimal relevante
        formato_num1 = int(num1) if num1.is_integer() else num1
        formato_num2 = int(num2) if num2.is_integer() else num2
        formato_res = int(resultado) if resultado.is_integer() else round(resultado, 4)

        print(f"\n✅ Resultado: {formato_num1} / {formato_num2} = {formato_res}")

    finally:
        print("\n" + "-" * 45)
        print("Fin de la ejecución del programa.")
        print("-" * 45)


if __name__ == "__main__":
    division_segura()
