# Programa para calcular el descuento en un comercio minorista

# 1. Solicitar por teclado el importe de la compra
importe_str = input("Introduzca el importe de la compra (€): ")
importe = float(importe_str)

# 2 y 3. Aplicar descuento del 10% si es superior a 100€, o no aplicar si es menor o igual
if importe > 100:
    descuento = importe * 0.10
    importe_final = importe - descuento
    print(f"¡Se aplica un 10% de descuento! Descuento: {descuento:.2f}€")
else:
    importe_final = importe
    print("No se aplica descuento.")

# 4. Mostrar por pantalla el importe final a pagar
print(f"El importe final a pagar es: {importe_final:.2f}€")
