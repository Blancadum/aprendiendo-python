"""
    Modulos para modificar texto
    str() -> Devuelve el texto en string
    lower() -> Devuelve el texto en minúsculas
    upper() -> Devuelve el texto en mayúsculas
    strip() -> Devuelve el texto sin espacios
    replace(old, new) -> Devuelve el texto con la palabra reemplazada
    count(word) -> Devuelve el número de veces que aparece la palabra
    startswith(word) -> Devuelve True si el texto empieza por la palabra
    endswith(word) -> Devuelve True si el texto termina por la palabra
    split(word) -> Devuelve el texto separado por la palabra
    join(word) -> Devuelve el texto unido por la palabra
"""