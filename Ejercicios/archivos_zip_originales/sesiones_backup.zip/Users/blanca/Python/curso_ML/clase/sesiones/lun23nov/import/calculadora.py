"""
    
"""
# Forma 1: importar modulo completo
import operaciones

n1 = 10
n2 = 4

print(operaciones.sumar(n1, n2))
print(operaciones.restar(n1, n2))
print(operaciones.multiplicar(n1, n2))
print(operaciones.dividir(n1, n2))

# Forma 2: importar el recurso del módulo que necesito
from operaciones import restar

print(restar)

# Forma 3: importar el recurso del módulo con otro nombre
from operaciones import multiplicar as prod

print(prod(n1, n2))