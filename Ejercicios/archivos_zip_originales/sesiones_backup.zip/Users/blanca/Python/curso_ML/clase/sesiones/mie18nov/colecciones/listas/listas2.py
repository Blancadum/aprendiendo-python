# crear una lista llamada colores con los valores rojo, verde y azul
colores = ["rojo", "verde", "azul"]

# mostrar el tipo de dato de la coleccion
print(type(colores))

# mostrar el contenido de la lista
print(colores)

# recorrer la lista con for in
print("\n--- Recorrer con for in ---")
for color in colores:
    print(color)

# recorrer la lista con for range
print("\n--- Recorrer con for range ---")
for i in range(len(colores)):
    print(colores[i])

# recorrer la lista con while
print("\n--- Recorrer con while ---")
i = 0
while i < len(colores):
    print(colores[i])
    i += 1

# mostrar el color verde (acceder por el indice)
print("\nColor verde por índice [1]:", colores[1])

# borrar el color azul
colores.remove("azul")
print("Lista tras borrar azul:", colores)

# crear una lista vacia mas_colores
mas_colores = []

# en la lista nueva unir el contenido de la lista colores con: blanco, negro, rosa, azul
mas_colores = colores + ["blanco", "negro", "rosa", "azul"]
print("mas_colores:", mas_colores)

# agregar el color naranja al final
mas_colores.append("naranja")
print("Tras agregar naranja al final:", mas_colores)

# agregar el color marron al principio
mas_colores.insert(0, "marrón")
print("Tras agregar marrón al principio:", mas_colores)

# mostrar la longitud de la lista
print("Longitud de la lista:", len(mas_colores))

# mostrar el antepenultimo elemento
print("Antepenúltimo elemento [-3]:", mas_colores[-3])

''' slices '''
# Mostrar los 2 ultimos elementos
print("2 últimos elementos:", mas_colores[-2:])

# Mostrar desde el ultimo hasta el antepenultimo
print("Desde el último hasta el antepenúltimo:", mas_colores[-1:-4:-1])

# Mostrar los 3 primeros
print("3 primeros:", mas_colores[:3])

# Mostrar del segundo al cuarto
print("Del segundo al cuarto:", mas_colores[1:4])

# Mostrar del primero al penultimo de 2 en 2
print("Del primero al penúltimo de 2 en 2:", mas_colores[:-1:2])

lista = mas_colores

# Mostrar los últimos 4 elementos
print("Últimos 4:", lista[-4:])

# Mostrar todos los elementos
print("Todos:", lista[:])

# Mostrar los 5 primeros
print("5 primeros", lista[0:5]) # igual que los rangos el ultimo no entra
print("5 primeros", lista[:5])

# Mostrar los elementos del indice 3 al indice 6
print("Del 3 al 6", lista[3:7])

# Mostrar los elementos del indice 6 al indice 3
print("Del 6 al 3", lista[6:3]) # vacio
print("Del 6 al 3", lista[6:3:-1])

# Mostrar los elementos del indice 6 al indice 3 pero por la derecha
print("Del 6 al 3", lista[-6:-10:-1])
print("Del 6 al 3", lista[-6:2:-1])

# Mostrar todos en orden inverso
print("Todos", lista[::-1])

# Mostrar todos en orden inverso de 2 en 2
print("Todos", lista[::-2])

# Mostrar todos de 2 en 2
print("Todos", lista[::2])