'''
    Generar un numero aleatorio del 1 al 10
    Solicitar al usuario que lo adivine.
    Le teneis que dar pistas
    Si el usuario introduce un texto en vez de numero lanzar excepcion
'''
import random

numero = random.randint(1, 10)
adivinar = 0

while adivinar != numero:
    try:
        entrada = input("Adivina el numero: ")

        # Si el usuario introduce texto en vez de número, podemos lanzar excepción con raise
        # o dejar que int() lance ValueError automáticamente:
        if not entrada.lstrip("-").isdigit():
            raise ValueError("Has introducido un texto en lugar de un número.")

        adivinar = int(entrada)

        if adivinar < numero:
            print("Te has quedado corto, vuelve a intentarlo")
        elif adivinar > numero:
            print("Te has pasado, vuelve a intentarlo")
        else:
            print("Enhorabuena, lo adivinaste")

    except ValueError as error:
        print("Error capturado:", error)
        print("Por favor, introduce un número entero del 1 al 10.\n")
