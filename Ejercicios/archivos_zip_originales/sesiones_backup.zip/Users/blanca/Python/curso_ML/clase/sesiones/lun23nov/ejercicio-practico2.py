"""
Gestión de Stock en Almacén con Diccionarios y Funciones
1. Crear un diccionario donde las claves sean nombres de productos y los valores sus cantidades.
2. Definir una función llamada actualizar_stock que reciba el diccionario, el nombre del producto y la cantidad a sumar.
3. Añadir 3 productos iniciales.
4. Llamar a la función para modificar uno de ellos y mostrar el diccionario final.

Autor: Blanca de Uña Martín
Curso: Python - Agentic
"""

# 2. Definición de la función para actualizar el stock
def actualizar_stock(inventario: dict, producto: str, cantidad: int) -> dict:
    """
    Actualiza la cantidad de un producto sumándole la cantidad recibida.
    1. Si el producto ya existe en el diccionario, suma la cantidad al valor actual.
    2. Si el producto es nuevo, lo añade con la cantidad especificada.
    """
    if producto in inventario:
        inventario[producto] += cantidad
    else:
        inventario[producto] = cantidad
    return inventario


# 1 y 3. Creación del diccionario con 3 productos iniciales
stock_repuestos = {
    "bujías": 50,
    "pastillas de freno": 20,
    "filtros de aceite": 35
}

# Mostrar el inventario inicial
print("=== Stock inicial del almacén ===")
for prod, cant in stock_repuestos.items():
    print(f" - {prod.capitalize()}: {cant} unidades")

# 4. Se llama a la función para cambiar uno de ellos (añadimos 25 bujías)
print("\n--> Actualizando stock: sumando 25 unidades a 'bujías'...")
actualizar_stock(stock_repuestos, "bujías", 25)

# Mostrar el diccionario final completo
print("\n=== Diccionario final de stock ===")
print("Estructura diccionario:", stock_repuestos)
print("\nDesglose final:")
for prod, cant in stock_repuestos.items():
    print(f" - {prod.capitalize()}: {cant} unidades")
