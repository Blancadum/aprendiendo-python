numeros1 = {1, 2, 3, 4, 5, 6, 7, 8, 9}
numeros2 = {0, 2, 4, 6, 8, 10}

# Intersección de conjuntos: elementos comunes

