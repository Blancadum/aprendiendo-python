"""
Introducción a la definición y llamada de funciones en Python.
Demuestra:
- Tipado opcional de variables y funciones (type hints).
- Funciones sin retorno (retornan None).
- Funciones con retorno (return).
- Funciones con argumentos posicionales obligatorios.
- Invocación de funciones y captura/impresión de sus valores de retorno.

Autor: Blanca de Uña Martín
Curso: Machine Learning
"""

num = 7
num2: int = 6  # de forma opcional puedo poner el tipo de dato a la variable

# Funcion sin retorno
# El tipo de dato que retorna una funcion tambien es opcional
# -> None quiere decir que la funcion no retorna nada
def saludar() -> None:
    print("Buenas tardes")

# Funcion con retorno
# -> str la funcion retorna una cadena de texto
def despedir() -> str:
    mensaje = "Hasta mañana"
    return mensaje

# Funcion con 2 argumentos
def sumar(n1: int, n2: int) -> int:
    return n1 + n2

''' A las funciones hay que llamarlas (invocar) '''
saludar()
msg = despedir()
print(despedir())
# print(sumar()) # TypeError: sumar() missing 2 required positional arguments: 'n1' and 'n2'
print(sumar(7,2)) # Si la funcion tiene declarados 2 argumentos, es obligatorio pasarle esos datos
