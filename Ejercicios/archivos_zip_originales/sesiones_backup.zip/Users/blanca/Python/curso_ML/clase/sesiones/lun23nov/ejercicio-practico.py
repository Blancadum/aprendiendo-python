"""
Caso Práctico: Configuración de entorno e identificación de sistema

Requerimientos:
1. Instalar el intérprete de Python 3.x.
2. Crear un archivo llamado inicio.py.
3. Declarar dos variables: nombre_empresa y año_actual.
4. Imprimir un mensaje de bienvenida que concatene ambas variables.
5. Ejecutar el script desde la terminal.

Autor: Blanca de Uña Martín
Curso: Machine Learning
"""

# Declaración de variables requeridas
nombre_empresa = "Tech Consulting Solutions"
año_actual = 2026

# Mensaje de bienvenida que concatena ambas variables
print(f"¡Bienvenido al sistema corporativo de {nombre_empresa}! Año operativo: {año_actual}")
