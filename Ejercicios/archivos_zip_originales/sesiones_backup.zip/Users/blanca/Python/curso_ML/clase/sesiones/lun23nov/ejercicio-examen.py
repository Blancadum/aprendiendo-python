"""
EVALUACIÓN MÓDULO 3 - TEST (Respuestas y Demostraciones)

Autor: Blanca de Uña Martín
Curso: Machine Learning
"""

# ==============================================================================
# 1. ¿Qué devuelve una función si no tiene una sentencia 'return' explícita?
# RESPUESTA CORRECTA: c) None
# ==============================================================================
def funcion_sin_return():
    pass

resultado = funcion_sin_return()
print("1. Retorno por defecto de una función sin return:", resultado)  # Imprime: None


# ==============================================================================
# 2. ¿Cuál es la principal diferencia entre una lista y una tupla?
# RESPUESTA CORRECTA: c) Las tuplas son inmutables
# ==============================================================================
mi_lista = [1, 2, 3]  # Mutable: se puede modificar, añadir o borrar
mi_tupla = (1, 2, 3)  # Inmutable: no se pueden modificar sus elementos

mi_lista[0] = 99  # Permitido en listas
print("2. Lista mutable:", mi_lista)
# mi_tupla[0] = 99 -> TypeError: 'tuple' object does not support item assignment


# ==============================================================================
# 3. ¿Cómo se define una función en Python?
# RESPUESTA CORRECTA: b) def miFuncion():
# ==============================================================================
def miFuncion():
    return "Hola desde miFuncion"

print("3. Definición con 'def':", miFuncion())


# ==============================================================================
# 4. ¿Qué método se usa para añadir un elemento al final de una lista?
# RESPUESTA CORRECTA: c) append()
# ==============================================================================
elementos = ["a", "b"]
elementos.append("c")  # Añade al final
print("4. Método append():", elementos)


# ==============================================================================
# 5. En un diccionario, ¿cómo se accede al valor asociado a una clave 'color'?
# RESPUESTA CORRECTA: a) diccionario['color']
# (OJO: en la captura estaba marcada la 'c' diccionario.get(0), pero esa buscaría la clave 0, no 'color')
# ==============================================================================
diccionario = {"color": "rojo", "talla": "M"}
valor = diccionario['color']
print("5. Acceso por corchetes diccionario['color']:", valor)  # Imprime: rojo
