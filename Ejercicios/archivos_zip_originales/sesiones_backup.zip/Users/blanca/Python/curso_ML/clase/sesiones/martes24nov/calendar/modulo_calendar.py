from calendar import *
import locale

# Mostrar el calendario de 2026, w=4 es el ancho de la columna, l=2 alto de la fila, c=10 es el espacio entre columnas, m=2 muestra 2 meses por fila
print(calendar(2026, w=4, l=2, c=10, m=2))

# Mostrar el calendario de 2026 w=4 es el ancho de la columna, l=2 alto de la fila, c=10 es el espacio entre columnas
print(calendar(2026,w=4, l=2, c=10))  


# Mostrar calendario de Diciembre de 2026
print(month(2026,12))


# Si quiero que la semana comience en domingo
setfirstweekday(6) # lunes es 0
setfirstweekday(SUNDAY) # con la constante
print(month(2026,12))


# Retorna si un año es bisiesto
print("2024 es bisiesto?", isleap(2024)) # True
print("2023 es bisiesto?", isleap(2023)) # False

# ¿Cuántos años bisiestos hay entre un rango de años?
print("Cuántos años bisiestos hay entre un rango de años?", leapdays(2010, 2024)) # 3
print("¿Cuántos bisiestos entre 2010 y 2024?", leapdays(2010, 2025)) # 4

# Calendario en español
locale_es = locale.setlocale(locale.LC_ALL, "es_ES.UTF-8")
calendario_es = LocaleTextCalendar(locale=locale_es)

