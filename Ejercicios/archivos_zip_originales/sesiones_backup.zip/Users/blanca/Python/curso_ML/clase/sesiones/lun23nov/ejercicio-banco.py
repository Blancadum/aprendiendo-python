'''
    Ejemplo del banco:
        - partimos de un saldo de 1000 euros
        - el usuario quiere retirar 1200, al ser insuficiente lanzar excepcion
'''
saldo = 1000

def retirar(importe):
    # ERROR ORIGINAL: Falta 'global saldo'.
    # Al modificar 'saldo -= importe' en la línea del else, Python considera que
    # 'saldo' es una variable LOCAL a la función. Al intentar leerla en el 'if'
    # lanza: UnboundLocalError: local variable 'saldo' referenced before assignment.
    global saldo
    if importe > saldo:
        raise Exception("No tienes saldo suficiente")
    else:
        saldo -= importe

try:
    retirar(1200)
except Exception as ex:
    print(ex)
else:
    print("Saldo actual", saldo)
