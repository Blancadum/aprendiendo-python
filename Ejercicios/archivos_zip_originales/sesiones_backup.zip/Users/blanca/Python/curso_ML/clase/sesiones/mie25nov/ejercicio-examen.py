"""
EVALUACIÓN MÓDULO 4 - TEST (Respuestas y Demostraciones de Código)

Autor: Blanca de Uña Martín
Curso: Python Fundae - Evaluación Módulo 4
"""

# ==============================================================================
# 1. ¿Qué instrucción se usa para forzar (lanzar) una excepción manualmente?
# RESPUESTA CORRECTA: b) raise
# ==============================================================================


def demostrar_raise():
    saldo = 100
    retirada = 150
    if retirada > saldo:
        raise ValueError(
            "Fondos insuficientes (lanzado manualmente con 'raise')"
        )


try:
    print("1. Demostración de raise:")
    demostrar_raise()
except ValueError as e:
    print("   Capturado correctamente:", e)


# ==============================================================================
# 2. ¿Para qué sirve el bloque 'finally'?
# RESPUESTA CORRECTA: c) Para ejecutar código siempre, haya error o no
# ==============================================================================
print("\n2. Demostración de finally:")
try:
    x = 10 / 2
except ZeroDivisionError:
    print("   Hubo error")
finally:
    print("   El bloque 'finally' se ha ejecutado siempre.")


# ==============================================================================
# 3. ¿Cuál es el bloque de código que se ejecuta si ocurre un error en un 'try'?
# RESPUESTA CORRECTA: b) except
# ==============================================================================
print("\n3. Demostración de except:")
try:
    numero = int("no_es_numero")
except ValueError:
    print("   El bloque 'except' se activa al fallar la conversión.")


# ==============================================================================
# 4. ¿Qué palabra clave se usa para importar una librería externa?
# RESPUESTA CORRECTA: c) import
# ==============================================================================
import math

print("\n4. Demostración de import:")
print("   math.pi =", math.pi)


# ==============================================================================
# 5. ¿Cómo se importa solo la función 'sqrt' del módulo 'math'?
# RESPUESTA CORRECTA: b) from math import sqrt
# ==============================================================================
from math import sqrt

print("\n5. Demostración de from math import sqrt:")
print("   sqrt(25) =", sqrt(25))
