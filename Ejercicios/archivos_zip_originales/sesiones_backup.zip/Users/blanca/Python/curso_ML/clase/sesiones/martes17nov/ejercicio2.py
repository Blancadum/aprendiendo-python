"""
Enunciado:
Crear una función calcular_precio que recibe el precio del producto y el porcentaje de descuento (ej. 10).
Retornar el precio final.

Probar con diferentes precios y descuentos.

Autor: Blanca de Uña Martín
Curso: Machine Learning
"""

def calcular_precio(precio: float, porcentaje_descuento: float = 10.0) -> float:
    descuento = precio * (porcentaje_descuento / 100)
    precio_final = precio - descuento
    return precio_final

# Pruebas con diferentes precios y descuentos
if __name__ == "__main__":
    # Prueba 1: 100€ con 10% de descuento
    p1 = 100.0
    dto1 = 10.0
    final1 = calcular_precio(p1, dto1)
    print(f"Precio: {p1:.2f}€ | Descuento: {dto1:.0f}% -> Precio final: {final1:.2f}€")

    # Prueba 2: 50€ con 20% de descuento
    p2 = 50.0
    dto2 = 20.0
    final2 = calcular_precio(p2, dto2)
    print(f"Precio: {p2:.2f}€ | Descuento: {dto2:.0f}% -> Precio final: {final2:.2f}€")

    # Prueba 3: 250€ con 15% de descuento
    p3 = 250.0
    dto3 = 15.0
    final3 = calcular_precio(p3, dto3)
    print(f"Precio: {p3:.2f}€ | Descuento: {dto3:.0f}% -> Precio final: {final3:.2f}€")

    # Prueba 4: 80€ usando el descuento por defecto (10%)
    p4 = 80.0
    final4 = calcular_precio(p4)
    print(f"Precio: {p4:.2f}€ | Descuento (defecto 10%) -> Precio final: {final4:.2f}€")
