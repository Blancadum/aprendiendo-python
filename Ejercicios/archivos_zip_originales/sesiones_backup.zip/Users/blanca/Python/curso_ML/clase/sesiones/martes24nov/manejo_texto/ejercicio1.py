"""
    1. Sustituir Java por Python
    2. Cuántas veces aparece la palabra Java
    3. Comprobar si empieza por "Me gusta"
    4. Comprobar si termina por "divertido"
    5. Longitud
    6. Caracter máximo y mínimo
    7. Transformar a Mayúsculas
    8. Transformar a minúsculas
"""

# Declaración de la frase inicial al principio para poder utilizarla
frase = "Me gusta Java porque Java es divertido"

# 1. Sustituir Java por Python
frase1 = frase.replace("Java", "Python")
print("1. Sustituir Java por Python:", frase1)

# 2. Cuántas veces aparece la palabra Java
frase2 = frase.count("Java")
print("2. Cuántas veces aparece la palabra Java:", frase2)

# 3. Comprobar si empieza por "Me gusta" (startswith con 's')
frase3 = frase.startswith("Me gusta")
print("3. Comprobar si empieza por 'Me gusta':", frase3)

# 4. Comprobar si termina por "divertido" (endswith con 's')
frase4 = frase.endswith("divertido")
print("4. Comprobar si termina por 'divertido':", frase4)

# 5. Longitud
frase5 = len(frase)
print("5. Longitud de la frase:", frase5)

# 6. Caracter máximo y mínimo (funciones max() y min())
frase6_max = max(frase)
frase6_min = min(frase)
print("6. Caracter máximo:", frase6_max)
print("6. Caracter mínimo:", repr(frase6_min), "(es el espacio en blanco)")

# 7. Transformar a Mayúsculas
frase7 = frase.upper()
print("7. Transformar a mayúsculas:", frase7)

# 8. Transformar a minúsculas
frase8 = frase.lower()
print("8. Transformar a minúsculas:", frase8)

# ==============================================================================
# 📝 APUNTES DIDÁCTICOS: ANÁLISIS DE FALLOS COMUNES Y CÓMO RECORDARLOS
# ==============================================================================
# 1. ORDEN SECUENCIAL (NameError):  
#    - Fallo: Declarar la variable 'frase' al final del script tras haberla usado.
#    - Regla: Python es un lenguaje interpretado que se ejecuta de arriba a abajo.
#      Cualquier variable debe crearse antes de intentar leerla o llamar a sus métodos.
#
# 2. CONJUGACIÓN EN MÉTODOS DE COMPROBACIÓN ('s' de 3ª persona en inglés):
#    - Fallo: Escribir .startwith() y .endwith() (falta la 's').
#    - Regla: En inglés se usa la 3ª persona: "it starts with" y "it ends with".
#      Por tanto, los métodos correctos son: .startswith() y .endswith().
#
# 3. MÉTODOS DE OBJETO vs FUNCIONES GLOBALES (max() vs .max):
#    - Fallo: Escribir frase.max como si fuera un método o propiedad de las cadenas.
#    - Regla:
#      * Métodos de string (con punto): frase.upper(), frase.lower(), frase.replace().
#      * Funciones generales integradas (built-in): len(frase), max(frase), min(frase).
#        Se aplican a cualquier iterable pasando la variable entre paréntesis.
# ==============================================================================

"""
    Modulos/métodos para modificar texto:
    str() -> Devuelve el texto en string
    lower() -> Devuelve el texto en minúsculas
    upper() -> Devuelve el texto en mayúsculas
    strip() -> Devuelve el texto sin espacios al inicio y final
    replace(old, new) -> Devuelve el texto con la palabra reemplazada
    count(word) -> Devuelve el número de veces que aparece la palabra
    startswith(word) -> Devuelve True si el texto empieza por la palabra
    endswith(word) -> Devuelve True si el texto termina por la palabra
    split(word) -> Devuelve el texto separado por la palabra
    join(word) -> Devuelve el texto unido por la palabra
"""
