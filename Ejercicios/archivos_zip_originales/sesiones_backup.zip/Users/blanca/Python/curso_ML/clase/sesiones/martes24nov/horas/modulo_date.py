import datetime
# Fecha y hora actual
print("Ahora:", datetime.datetime.now())
print("Hoy:", datetime.date.today())

fecha_hora = datetime.datetime(2027, 1, 26, 8, 30)
print(fecha_hora)
fecha_hora.year
fecha_hora.month
fecha_hora.day
fecha_hora.hour
fecha_hora.minute

timedelta = datetime.timedelta(weeks=1, hours=3)
print("Dentro de una semana:", fecha_hora + timedelta)
print("Hace 2 días:", fecha_hora - datetime.timedelta(days=2))

print(fecha_hora.date().strftime("%d/%m/%Y")) # 26/01/2027
print(fecha_hora.strftime("%A %d %B %Y")) # martes 26 enero 2027
print(fecha_hora.strftime("%a %d %b %Y %H:%M")) # mar 26 ene 2027 08:30
print(fecha_hora.strftime("%A %d %B %Y %H:%M:%S")) # martes 26 enero 2027 08:30:00
print(fecha_hora.strftime("%A %d %B %Y %H:%M:%S %p")) # martes 26 enero 2027 08:30:00 AM

