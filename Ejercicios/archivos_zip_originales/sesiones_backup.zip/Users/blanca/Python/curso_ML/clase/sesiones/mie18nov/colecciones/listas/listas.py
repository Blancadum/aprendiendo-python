"""

"""

# Lista: coleciones ordenadas de elementso (tienesn índice)
# en todas las colecciones los elementos pueden ser de diferentess tipos
# Permite elementos duplicados
# son mutables: permite modificar, añadir, eliminar
# Se crean con []

list1 = ['Maria', 'Pérez', 30, 'soltera', 'sin hijos']
list2 = ['estudiante', 'medicina', '20020']

# tipo de listas
print(type(list1)) # <class 'list'>

# mostrar las listas
print(list1)
print(list2)

# crear listas con list()
list3 = list()
print(type(list3))

# crear lista vacía
lista_vacia = []
lista = list()

# unir listas (el orden es importante)
lista_vacia = list1 + list2
print(lista_vacia)
lista = list2 + list1
print(lista)

# longitud de la lista (número de elementos)
print("La longitud de la lista:", len(lista))

# Acceso a elementos de la l ista
# si el índice es positivo, empezamos por la izquierda
# si el índice es negativo, empezamos por la derecha
print("codigo postal; ", lista[2])
print("estado civil", lista[-2])
print("estado civil", lista[len(lista)-1])

#Agregar un elemento al final de la lista
lista.append("morena") #append es un método porque está declarado dentro de la clase list
print(lista)

# Agregar elemento en una determinada posición
lista.insert(0, 1.75)
print(lista)

# Agregar varios elementos a la vez al final
lista.extend([1,2,3])
print(lista)

# Eliminar un elemento por su valor
list1.remove('Maria')
print(list1)

# Modificar un elemento de la lista
lista[-4] = "1 hijo"
print(lista)

# Mostrar el indice donde esta "medicina"
print("Medicina esta en el indice", lista.index("medicina"))
# ValueError: list.index(x): x not in list
#print("Medicina esta en el indice", lista.index("medicina", 6))

# Contar cuantos elementos 'estudiante' tengo
print("Tengo", lista.count('estudiante'), "elementos 'estudiante'")

# Recorrer la lista for in
for elemento in lista:
    print(elemento, end="-")
else: # se ejecuta cuando no tengo mas elementos
    print("\n-----------")

# --- Explicación de 'else' en bucles for vs 'break' ---
# La diferencia aparece cuando hay un 'break':
# - Un print puesto a la altura del 'for' se ejecuta SIEMPRE, salga el bucle como salga.
# - El bloque 'else' SOLO se ejecuta si el bucle NO salió por 'break'.
#
# Ejemplo 1 (sin else):
# for n in [3, -1, 5]:
#     if n < 0:
#         break
# print("fin")   # se imprime aunque haya hecho break
#
# Ejemplo 2 (con else):
# for n in [3, -1, 5]:
#     if n < 0:
#         break
# else:
#     print("fin")   # NO se imprime, porque salió por break
#
# Conclusión: El 'else' solo tiene sentido si dentro del bucle hay un 'break'.
# Sin 'break', ponerlo a la altura del for es lo mismo y queda más claro.

# Recorrer la lista for range
for indice in range(len(lista)):
    print(lista[indice])