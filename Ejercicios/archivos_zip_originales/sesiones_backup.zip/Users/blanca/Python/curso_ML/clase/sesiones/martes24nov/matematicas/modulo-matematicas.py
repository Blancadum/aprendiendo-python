'''
Módulo de matematicas
'''

import math

print("Potencia 2 elevado a 8:", math.pow(2,8)) # Potencia 2 elevado a 8: 256.0
print("PI:", math.pi) #PI: 3.141592653589793
print("Logaritmo base 10 1000", math.log(1000)) # Logaritmo base 10 1000 6.907755278982137
print("Seno de 90:", math.sin(math.radians(90))) # Seno de 90: 1.0
print("Factorial de 4:", math.factorial(4)) # Factorial de 4: 24
print("Raiz cuadrada de 9", math.sqrt(9)) # Raiz cuadrada de 9 3.0


# Redondeos

print("Redondear a 2 decimales 6.765456", round(6.765456, 2)) # 6.77

print("Redondear al alza 3.89", math.ceil(3.89)) # Redondear al alza 3.89 4
print("Redondear al alza 3.19", math.ceil(3.19)) # Redondear al alza 3.19 4
print("Redondear al alza -3.19", math.ceil(-3.19)) # Redondear al alza -3.19 -3

print("Redondear a la baja 3.89", math.floor(3.89)) # Redondear a la baja 3.89 3
print("Redondear a la baja 3.19", math.floor(3.19)) # Redondear a la baja 3.19 3
print("Redondear a la baja -3.19", math.floor(13.19)) # Redondear a la baja -3.19 13

print("Truncar 3.89 ", math.trunc(3.89)) # Truncar 3.89  3
print("Truncar 3.19 ", math.trunc(3.19)) # Truncar 3.19  3
print("Truncar -3.89 ", math.trunc(-3.89)) # Truncar 3.89  -3