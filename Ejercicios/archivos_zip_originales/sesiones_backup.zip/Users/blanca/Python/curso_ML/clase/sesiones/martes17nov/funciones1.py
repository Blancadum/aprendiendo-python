"""
Enunciado:
Solicitar 2 números al usuario y ejecutar las 4 operaciones básicas.
Crear una calculadora con 5 funciones:
- sumar, restar, multiplicar, dividir: muestran el resultado por consola.
- validar_divisor: retorna True o False para indicar si se puede realizar la división.

Ejemplos de lógica:
dividir(7, 0)
    resultado = validar_divisor(0) -> Devuelve False.
    "Lo siento, no puedo hacer la división"

dividir(7, 2)
    resultado = validar_divisor(2) -> Devuelve True.
    Muestra el resultado de la división

Autor: Blanca de Uña Martín
Curso: Machine Learning
"""

def sumar(n1: int, n2: int) -> int:
    suma = n1 + n2
    print(f"{n1} + {n2} = {suma}")

def restar(n1: int, n2: int) -> int:
    resta = n1 - n2
    print(f"{n1} - {n2} = {resta}")

def multiplicar(n1: int, n2: int) -> int:
    multiplicacion = n1 * n2
    print(f"{n1} * {n2} = {multiplicacion}")

def dividir(n1: int, n2: int) -> float:
    correcto = validar_divisor(n2)
    if correcto == True:
        division = n1 / n2
        print(f"{n1} / {n2} = {division}")
    else:
        print("Lo siento no puedo hacer la division")

def validar_divisor(divisor: int) -> bool:
    if divisor == 0:
        return False
    else:
        return True

# Solicitar 2 números al usuario y ejecutar las operaciones
if __name__ == "__main__":
    n1 = int(input("Introduce el primer número: "))
    n2 = int(input("Introduce el segundo número: "))

    sumar(n1, n2)
    restar(n1, n2)
    multiplicar(n1, n2)
    dividir(n1, n2)
