# Colecciones en Python

## Listas

- Una lista es un conjunto ordenado de elementos que puede contener datos de cualquier tipo. Es el tipo de colección más flexible de todos.
- Las listas pueden contener elementos del mismo tipo o elementos de diferentes tipos.
- En Python las listas se delimitan con corchetes `[ ]`, con los elementos separados por comas.
- La función/propiedad `len` devuelve la longitud, es decir, el número de elementos que contiene la lista.
- El primer elemento de una lista es el elemento 0, no el 1.

### Ejemplo:

```python
lista = ["ordenador", "teclado", "raton"]
print(len(lista))
print(lista[0])
print(lista[1])
print(lista[2])
```

## Operaciones básicas con listas

- **Unir listas con el operador `+`:**

```python
listaoriginal = ["ordenador", "teclado", "raton"]
listanueva = ["monitor", "impresora", "altavoces"]
listafinal = listaoriginal + listanueva
print(listafinal)
```

- **Añadir un elemento a la lista con el operador `+`:**

```python
lista = ["ordenador", "teclado", "raton"]
print(lista)
lista = lista + ["mesa"]
print(lista)
```

- **Eliminar un elemento de la lista con el operador `del`:**

```python
lista = ["ordenador", "teclado", "raton"]
print(lista)
del lista[1]
print(lista)
```

- **Búsqueda y conteo de elementos con `.index()` y `.count()`:**

```python
# .index(valor): devuelve el primer índice donde se encuentra el valor
print(lista.index("teclado"))  # Si no existe, lanza ValueError

# .index(valor, inicio): busca a partir de un índice específico
# print(lista.index("teclado", 3))

# .count(valor): cuenta cuántas veces aparece un elemento
print(lista.count("teclado"))
```

## Listas de dos dimensiones (listas anidadas)

Hasta ahora hemos visto listas de una sola dimensión. Si queremos listas de dos dimensiones necesitaríamos crear una lista como elemento de otra lista:

```python
lista = ["ordenador", "teclado", "raton", ["tarjeta de sonido", "microfono", "altavoces"]]
print(lista[0])
print(lista[1])
print(lista[2])
print(lista[3])
print(lista[3][0])
print(lista[3][1])
print(lista[3][2])
```

## Cláusula `else` en bucles `for` (comportamiento con `break`)

La diferencia entre poner un código al final con `else:` o simplemente fuera del `for`:
- Un `print` puesto a la altura del `for` se ejecuta **siempre**, salga el bucle como salga.
- El bloque `else` **solo** se ejecuta si el bucle **no** salió por `break`.

```python
for n in [3, -1, 5]:
    if n < 0:
        break
print("fin")    # se imprime aunque haya hecho break
```

```python
for n in [3, -1, 5]:
    if n < 0:
        break
else:
    print("fin")    # NO se imprime, porque salió por break
```

> **Conclusión:** El `else` solo tiene sentido si dentro del bucle hay un `break`. Sin `break`, poner el código a la altura del `for` es lo mismo y queda más claro.

## Slicing (Rebanado o partición de listas)

Sintaxis general: `lista[inicio:fin:paso]`
- Al igual que en `range()`, el índice final **no** se incluye.
- Si se omite `inicio`, empieza desde 0 (`lista[:5]`).
- Si se omite `fin`, va hasta el final (`lista[3:]`).
- Si `inicio > fin` con paso positivo por defecto, devuelve lista vacía `[]`. Para ir hacia atrás, se debe especificar paso negativo (`paso = -1`).

```python
# Mostrar los 5 primeros
print("5 primeros", lista[0:5]) # el último índice no entra
print("5 primeros", lista[:5])

# Mostrar los elementos del índice 3 al índice 6
print("Del 3 al 6", lista[3:7])

# Mostrar los elementos del índice 6 al índice 3
print("Del 6 al 3", lista[6:3])    # vacio [] porque el paso por defecto es +1
print("Del 6 al 3", lista[6:3:-1]) # con paso -1 recorre en sentido inverso

# Mostrar los elementos del índice 6 al índice 3 pero usando índices negativos (por la derecha)
print("Del 6 al 3", lista[-6:-10:-1])
print("Del 6 al 3", lista[-6:2:-1])

# Mostrar todos en orden inverso
print("Todos", lista[::-1])

# Mostrar todos en orden inverso de 2 en 2
print("Todos", lista[::-2])

# Mostrar todos de 2 en 2
print("Todos", lista[::2])
```
