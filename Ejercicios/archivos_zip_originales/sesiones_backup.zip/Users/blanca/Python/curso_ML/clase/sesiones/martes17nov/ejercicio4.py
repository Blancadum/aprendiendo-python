"""
    crear una función area_triangulo que recibe los argumentos necesarios necesarios para calcular el área
    la función retorna el resultado
    solicitar los datos por teclado
"""