import os
os.system("cls")

# Los bucles son partes del programa que se repiten

# Podemos encontrarnos con dos tipos de bucles:

# Los bucles finitos o determinados: aquellos que se repiten un numero 
# fijo de veces. Se construyen con FOR.

# Los bucles no finitos o indeterminados: aquellos que se repiten un numero 
# variable de veces. Se construyen con WHILE.


# Otra equivalencia de DO..WHILE con control de errores


while True:
    
    try:
        
        numero = int(input("Introduce un numero positivo par distinto de cero: "))
        resto = numero % 2          
            
        if ((numero <= 0) or (resto != 0)):
            print("No has escrito un numero correcto")
        else:
            break
        
    except:
        print("No has escrito un valor válido, repítelo")



print("El numero " + str(numero) + " es positivo, par y distinto de cero.")  
    
    
    
    
