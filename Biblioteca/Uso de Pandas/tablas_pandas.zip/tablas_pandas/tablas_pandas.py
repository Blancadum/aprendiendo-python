
# Creación de tablas o Dataframes con Pandas

# Antes de empezar con Pandas hay que instalar la librería usando el terminal

# Abrimos CMD o Powershell en modo administrador y ejecutamos:

#               pip install pandas


import os

os.system('cls' if os.name == 'nt' else 'clear')

directorio_actual = os.path.dirname(os.path.abspath(__file__))
valores_csv = os.path.join(directorio_actual, "valores.csv")

import pandas as pd         # Importamos la librería Pandas


# Creación de un Dataframe básico. Es similar a los Arrays básicos o NumPy.

# Creación de un Dataframe insertando valores

tabla1 = pd.DataFrame()


nombres = ['Juan', 'Laura', 'Pepe']
edades = [42, 40, 37]

tabla1['Nombre'] = nombres
tabla1['Edad'] = edades


print("Contenido de la Tabla 1\n")
print(tabla1)

print("\n")



# Creación de un Dataframe básico con índices en filas y columnas

tensiones = pd.DataFrame()

# creamos las columna
tensiones['Mañana'] = None
tensiones['Tarde'] = None
tensiones['Noche'] = None
tensiones['Horario'] = None

# añadimos filas por su nombre de fila
tensiones.loc['Lunes'] = ['Tensión', 'Alergia', 'Sedante', None]
tensiones.loc['Martes'] = ['Tensión', None, 'Alergia', None]
tensiones.loc['Miércoles'] = ['Protector', 'Alergia', 'Tensión', None]

print("Contenido de la Tabla Tensiones\n")

print(tensiones)

print("\n")

input("Presione Enter para continuar")

os.system('cls' if os.name == 'nt' else 'clear')



# Usando el fichero valores.csv

# Importacion basica de un Dataframe desde archivo .csv.
# Es similar a los Arrays básicos o NumPy.

tabla2 = pd.read_csv(valores_csv, sep=";", dtype="string")

# Podemos acceder a los datos por el índice de la columna o por el número de fila


    # Parámetros que se le pueden añadir:
    # sep="separador"       --- Si no se define toma por defecto la coma
    # dtype="tipo de dato"  --- Si no se define por defecto toma numeros enteros
    # header="none"         --- Podemos elegir tomar la cabecera del documento o no
print("Contenido de la Tabla 2\n")
print(tabla2)

print("Contenido de la Tabla 2, columna Notas\n")
print(tabla2['Nota'])    # Muestra la columna Notas
print()

print("Contenido de la Tabla 2, las 2 primeras filas\n")
print (tabla2[7:17])       # Muestra las filas de la 7 a la 16

print("\n")

input("Presione Enter para continuar")

os.system('cls' if os.name == 'nt' else 'clear')



# Usando el fichero valores2.csv

# Creación de un Dataframe con índices en filas y columnas desde archivo .csv
# Importamos el archivo valores2.csv

tabla3 = pd.read_csv(directorio_actual + "/valores2.csv", sep=";", dtype="string")


print("Contenido de la Tabla 3\n")
print(tabla3)

print("\n")

input("Presione Enter para continuar")

# Indicamos que columna queremos que sea el índice de las filas


tabla4 = tabla3.set_index('Dato')

print("Contenido de la Tabla 4, usando indice Dato de la tabla 3\n")
print(tabla4)

print("\n")

input("Presione Enter para continuar")

os.system('cls' if os.name == 'nt' else 'clear')



tabla5 = tabla3.set_index('Codigo')

print("Contenido de la Tabla 5, usando indice Codigo de la tabla 3\n")
print(tabla5)

print("\n")

input("Presione Enter para continuar")

os.system('cls' if os.name == 'nt' else 'clear')



# Usando el fichero colesterol.csv

tabla6 = pd.read_csv(directorio_actual + "/colesterol.csv", sep=";", dtype="string")

print("Contenido de la Tabla 6\n")
print(tabla6)
print("\n")

input("Presione Enter para continuar")

tabla7 = tabla6.set_index('index')

print("Contenido de la Tabla 7, usando indice index de la tabla 6\n")
print(tabla7)

print("\n")

input("Presione Enter para continuar")



# Importación de datos desde un fichero situado en GitHub


tabla8 = pd.read_csv('https://gitfront.io/r/InboxColon/3ecD7AGnQwDB/pythonfiles/raw/colesterol.csv', sep=',', decimal=',')
print(tabla8)

print("\n")

input("Presione Enter para continuar")